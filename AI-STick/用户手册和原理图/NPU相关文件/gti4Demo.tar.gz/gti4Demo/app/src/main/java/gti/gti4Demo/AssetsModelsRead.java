/***********************************************************************
 *
 * Copyright (c) 2017-2019 Gyrfalcon Technology Inc. All rights reserved.
 * See LICENSE file in the project root for full license information.
 *
 ************************************************************************/

package gti.gti4Demo;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.res.AssetManager;
import android.os.Environment;
import android.util.Log;

public class AssetsModelsRead {
    private AssetManager assetManager;
    private final String modelsPath;
    private final Activity activity;
    private String[] fileList;

    public interface FileSelectedListener {
        void fileSelected(File file);
    }
    private ListenerList<AssetsModelsRead.FileSelectedListener> fileListenerList =
            new ListenerList<AssetsModelsRead.FileSelectedListener>();

    public AssetsModelsRead(Activity activity, String initialPath) {
        this.modelsPath = initialPath;
        this.activity = activity;
        this.assetManager = activity.getResources().getAssets();
        loadFileList(this.modelsPath);
    }

    public Dialog createAssetsModelsReadDialog() {
        Dialog dialog = null;
        AlertDialog.Builder builder = new AlertDialog.Builder(this.activity);
        builder.setTitle(this.modelsPath);
        builder.setItems(fileList, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                String fileChosen = fileList[which];
                String filename = copyAssets(fileChosen, fileChosen); // copy from assets to /sdcard/gti/Models/
                if (filename != null )
                    fireFileSelectedEvent(new File(filename));
            }
        });

        dialog = builder.show();
        return dialog;
    }

    private void fireFileSelectedEvent(final File file) {
        fileListenerList.fireEvent(new ListenerList.FireHandler<AssetsModelsRead.FileSelectedListener>() {
            public void fireEvent(AssetsModelsRead.FileSelectedListener listener) {
                listener.fileSelected(file);
            }
        });
    }

    public void showDialog() {
        createAssetsModelsReadDialog().show();
    }

    private void loadFileList(String path) {
        String[] files = null;
        try {
            files = this.assetManager.list(path);
            Log.d("GTI_JNI", "files ");
        } catch (IOException e) {
            Log.e("GTI_JNI", "Failed to get asset file list.", e);
            return;
        }
        fileList = files;
    }

    public void addFileListener(AssetsModelsRead.FileSelectedListener listener) {
        fileListenerList.add(listener);
    }

    public void removeFileListener(AssetsModelsRead.FileSelectedListener listener) {
        fileListenerList.remove(listener);
    }

    public String copyAssets(String from, String to) {
        if (from != null) {
            String filename = this.modelsPath + File.separator + from;
            InputStream in = null;
            OutputStream out = null;
            try {
                in = this.assetManager.open(filename);
                File outFile = new File(Environment.getExternalStorageDirectory() + File.separator + "gti" + File.separator + "Models", to);
                out = new FileOutputStream(outFile);
                this.copyFile(in, out);
                return Environment.getExternalStorageDirectory() + File.separator + "gti" + File.separator + "Models" + File.separator + to;
            } catch (IOException e) {
                Log.e("tag", "Failed to copy asset file: " + filename, e);
            } finally {
                if (in != null) {
                    try {
                        in.close();
                    } catch (IOException e) {
                        ;
                    }
                }
                if (out != null) {
                    try {
                        out.close();
                    } catch (IOException e) {
                        ;
                    }
                }
            }
        }
        return null;
    };

    public void copyFile(InputStream in, OutputStream out) throws IOException {
        byte[] buffer = new byte[1024];
        int read;
        while ((read = in.read(buffer)) != -1) {
            out.write(buffer, 0, read);
        }
    };
};

