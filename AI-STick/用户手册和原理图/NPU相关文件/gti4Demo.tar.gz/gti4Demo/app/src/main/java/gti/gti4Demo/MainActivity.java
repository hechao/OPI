/***********************************************************************
*
* Copyright (c) 2017-2019 Gyrfalcon Technology Inc. All rights reserved.
* See LICENSE file in the project root for full license information.
*
************************************************************************/

package gti.gti4Demo;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Message;
import android.widget.Button;
import android.widget.ToggleButton;
import android.widget.ImageView;
import android.view.View;
import android.view.View.OnClickListener;
import android.util.Log;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.content.pm.PackageManager;

import android.Manifest;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;
import java.lang.String;

import android.os.Environment;
import android.os.Handler;

import static android.os.SystemClock.sleep;


public class MainActivity extends Activity {

    final int SLIDESHOW_INTERVEL = 30; // in ms - quickest possible
    //final int SLIDESHOW_INTERVEL = 800; // in ms  - a more visiable speed
    final int IMAGE_WIDTH = 224;
    final int IMAGE_HEIGHT = 224;
    final int IMAGE_DEPTH = 3;
    final int RESULT_COUNT = 3;
    final int PROB_SPACE = 20;

    Button button_next;
    Button button_previous;
    ToggleButton button_slideshow;
    ImageView image;
    private String imageFolder = Environment.getExternalStorageDirectory() + "/gti/Image_bmp/";

    private File folder = new File(imageFolder);
    ArrayList<File> imageList = new ArrayList<File> ();
    private int gIndex = 0;
    private String modelFile;

    Timer slideshow_timer;
    boolean slideshow_ready;

    public MainActivity() {
        slideshow_ready = false;
        slideshow_timer = new Timer();
        slideshow_timer.schedule(new TimerTask() {
            @Override
            public void run() {
                if(slideshow_ready) {
                    run_slideshow();
                };
            }
        }, SLIDESHOW_INTERVEL, SLIDESHOW_INTERVEL);
    }

    private void run_slideshow() {
        if (slideshow_ready) {
            gIndex++;
            if (gIndex == imageList.size())
                gIndex = 0;
            decodeAndClassifyImage(imageFolder + "/" + imageList.get(gIndex).getName());
        }
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        image = (ImageView) findViewById(R.id.imageView1);
        getModelFileName("/gti/Models/");

        if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(MainActivity.this, new String[]{
                    Manifest.permission.WRITE_EXTERNAL_STORAGE,
                    Manifest.permission.READ_EXTERNAL_STORAGE
            }, 1);
        }

        Log.d("gtiDemoActivity", "Loading gti_gti4Demo library.");
        System.loadLibrary("gti_gti4Demo");
        Log.d("gtiDemoActivity", "Loaded gti_gti4Demo library.");

        initEngine(1, 0); //type: demo type

        Log.d("gtiDemoActivity", "initEngine done.");
    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        slideshow_ready = false;
        destroyModel();
        Log.d("gtiDemoActivity", " Back key pressed.");
    }


    public boolean createImageList(String imageFolder) {
        this.folder = new File(imageFolder);
        if (!this.folder.exists()) {
            Log.d("gtiDemoActivity", "imageFolder " + imageFolder + " not found!");
            return false;
        }
        for (final File fileEntry : this.folder.listFiles()) {
            this.imageList.add(fileEntry);
            Log.d("gtiDemoActivity", imageFolder + "/" + fileEntry.getName());
        }
        this.gIndex = 0;

        if(this.imageList.size() > 0)
            decodeAndClassifyImage(imageFolder + "/" + this.imageList.get(this.gIndex).getName());

        Log.d("gtiDemoActivity", "createImageList done.");

        addListenerOnButton();
        Log.d("gtiDemoActivity", "addListenerOnButton done.");

        return true;
    }

/*
    protected void getModelFileName(String sub_dir) {
        AssetsModelsRead assetsFileDialog = new AssetsModelsRead(this, "Models");
        assetsFileDialog.addFileListener(new AssetsModelsRead.FileSelectedListener() {
            public void fileSelected(File file) {

                Log.d(getClass().getName(), "selected file " + file.toString());
                MainActivity.this.modelFile = file.toString();

                // load model
                Log.d(getClass().getName(), "load model file: " + MainActivity.this.modelFile );
                if( ! loadModel(MainActivity.this.modelFile) ) {
                    Log.d(getClass().getName(), "load model failed");
                    return;
                }
                Log.d(getClass().getName(), "loaded model file: " + MainActivity.this.modelFile );
                MainActivity.this.getImageDirectoryName( "/git/Image_bmp/" );

                Log.d(getClass().getName(), "opened dialog " + MainActivity.this.getClass().getName() );
            }
        });
        assetsFileDialog.showDialog();
    }
*/

    protected void getModelFileName(String sub_dir) {
        //super.onCreate(savedInstanceState);
        File mPath = new File(Environment.getExternalStorageDirectory() + sub_dir);
        Log.d(getClass().getName(), "model file list path " + mPath.toString());
        FileDialog fileDialog = new FileDialog(this, mPath, ".model");
        fileDialog.addFileListener(new FileDialog.FileSelectedListener() {
            public void fileSelected(File file) {
                Log.d(getClass().getName(), "selected file " + file.toString());
                MainActivity.this.modelFile = file.toString();

                // load model
                Log.d(getClass().getName(), "load model file: " + MainActivity.this.modelFile );
                if( ! loadModel(MainActivity.this.modelFile) ) {
                    Log.d(getClass().getName(), "load model failed");
                    return;
                }
                Log.d(getClass().getName(), "loaded model file: " + MainActivity.this.modelFile );
                MainActivity.this.getImageDirectoryName( "/git/Image_bmp/" );

                Log.d(getClass().getName(), "opened dialog " + MainActivity.this.getClass().getName() );
            }
        });
        fileDialog.showDialog();
    }

    protected void getImageDirectoryName(String sub_dir) {
        //super.onCreate(savedInstanceState);
        File mPath = new File(Environment.getExternalStorageDirectory() + sub_dir);
        FileDialog fileDialog = new FileDialog(MainActivity.this, mPath);
        fileDialog.addDirectoryListener(new FileDialog.DirectorySelectedListener() {
            public void directorySelected(File directory) {

                Log.d(getClass().getName(), "selected dir " + directory.toString());
                MainActivity.this.imageFolder = directory.toString();

                MainActivity.this.folder = new File(MainActivity.this.imageFolder);
                Log.d("gtiDemoActivity", "Got image folder: " + MainActivity.this.imageFolder);

                MainActivity.this.createImageList(MainActivity.this.imageFolder);
            }
        });
        fileDialog.setSelectDirectoryOption(true);
        fileDialog.showDialog();
    }

    public void decodeAndClassifyImage(String imagename)
    {
        String[] predictions;
        Bitmap bitmap;
        final int[] imgData = new int[IMAGE_WIDTH * IMAGE_HEIGHT];
        final byte[] rgbData = new byte[IMAGE_WIDTH * IMAGE_HEIGHT * IMAGE_DEPTH];

        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inPreferredConfig = Bitmap.Config.ARGB_8888;
        options.outWidth = IMAGE_WIDTH;
        options.outHeight = IMAGE_HEIGHT;

        Log.d("gtiDemoActivity", "decode image file: " + imagename );
        bitmap = BitmapFactory.decodeFile(imagename, options);

        Bitmap scaledBitmap = Bitmap.createScaledBitmap(bitmap, IMAGE_WIDTH, IMAGE_HEIGHT, true);

        if( image == null ) {
            Log.d("gtiDemoActivity", "invalid ImageView object" );
            return;
        }
        image.setImageBitmap(scaledBitmap);

        scaledBitmap.getPixels(imgData, 0, IMAGE_WIDTH, 0, 0, IMAGE_WIDTH, IMAGE_HEIGHT);

        final int section2_offset = IMAGE_WIDTH * IMAGE_HEIGHT;
        final int section3_offset = IMAGE_WIDTH * IMAGE_HEIGHT * 2;
        /* convert to raw 8 bit per channel BGR plannar format */
        for(int i = 0; i < IMAGE_HEIGHT; i++) {
            int offset1 = IMAGE_WIDTH * i;
            int offset2 = section2_offset + offset1;
            int offset3 = section3_offset + offset1;
            for (int j = 0; j < IMAGE_WIDTH; j++)
            {
                rgbData[offset1 + j] = (byte)((imgData[offset1 + j]) & 0xFF);
                rgbData[offset2 + j] = (byte)((imgData[offset1 + j] >> 8) & 0xFF);
                rgbData[offset3 + j] = (byte)((imgData[offset1 + j] >> 16) & 0xFF);
            }
        }

        Log.d("gtiDemoActivity", "predict " );
        //predictions = oneFramePredict(rgbData);
        predictions = oneFramePredictFile(imagename, RESULT_COUNT);
        if(predictions == null)
        {
            Log.d("gtiDemoActivity", "oneFramePredictFile got null pointer." );
            return;
        }
        // native library returns an array with 3 elements containing the top 3 most likely
        // classification for this image
        Log.d("gtiDemoActivity", "predicted " );

        TextView[] txtView = {
                (TextView) findViewById(R.id.textView1),
                (TextView) findViewById(R.id.textView2),
                (TextView) findViewById(R.id.textView3)
        } ;
        for(int i=0; i<RESULT_COUNT; i++) {
            // parse prediction string for each predicted class
            // in each prediction, the first 20 characters contains the probability, the rest
            // contains the name of the class, with the max length of the string to be 99
            // many models use a number to be the name, which is not descriptive
            // we could try to parse the first token of the name, then
            Log.d("gtiDemoActivity", predictions[i]);
            char[] dispText = predictions[i].toCharArray();
            int probLimit = PROB_SPACE;
            if(predictions[i].length() > probLimit) {
                // check to make sure the string contains valid alphabet for prob and class name,
                // abort displaying classification if not
                if( dispText[0] == '1') {
                    dispText[1] = '.';
                    for (int anyi=2; anyi<probLimit; anyi++) {
                        dispText[anyi] = '0';
                    }
                }
                int probStop = 0;
                for (probStop = 0; probStop < probLimit; probStop++) {
                    if ((dispText[probStop] < '0' || dispText[probStop] > '9')
                    &&  (dispText[probStop] != '.' )) {
                        break;
                    }
                }
                if( probStop < probLimit ) {
                    for (int anyi=probStop; anyi<probLimit; anyi++) {
                        dispText[anyi] = '0';
                    }
                }

                int labelStop = 0;
                for (labelStop = probLimit; labelStop < predictions[i].length(); labelStop++) {
                    if ((dispText[labelStop] < 'a' || dispText[labelStop] > 'z')
                     && (dispText[labelStop] < 'A' || dispText[labelStop] > 'Z')
                     && (dispText[labelStop] < '0' || dispText[labelStop] > '9')
                     && (dispText[labelStop] != ' ' )
                     && (dispText[labelStop] != '-' )
                     && (dispText[labelStop] != ',' )) {
                        break;
                    }
                }

                // display 4 significant digits for the probability
                CharSequence txtviewprob = predictions[i].subSequence(0, 6);
                CharSequence txtviewclass = predictions[i].subSequence(probLimit, labelStop);
                txtView[i].setText(txtviewprob + " -- " + txtviewclass);
            }
        }
    }

    public void addListenerOnButton() {

        image = (ImageView) findViewById(R.id.imageView1);
        button_next = (Button) findViewById(R.id.btnNext);
        button_previous = (Button) findViewById(R.id.btnPrevious);
        button_slideshow = (ToggleButton) findViewById(R.id.btnSlideShow);

        button_next.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View arg0) {
                gIndex++;
                if(gIndex == imageList.size())
                    gIndex = 0;
                decodeAndClassifyImage(imageFolder + "/" + imageList.get(gIndex).getName());
            }
        });

        button_previous.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View arg0) {
                gIndex--;
                if(gIndex < 0)
                    gIndex = imageList.size() - 1;
                decodeAndClassifyImage(imageFolder + "/" + imageList.get(gIndex).getName());
            }
        });

        button_slideshow.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View arg0) {
                if(slideshow_ready) {
                    slideshow_ready = false;
                    button_previous.setEnabled(true);
                    button_next.setEnabled(true);
                }
                else {
                    button_next.setEnabled(false);
                    button_previous.setEnabled(false);
                    slideshow_ready = true;
                }
            }
        });
    }
    public native void initEngine(int network, int type);
    public native boolean loadModel(String model);
    public native boolean destroyModel();
    public native String[] oneFramePredictFile(String imgPath, int nresult);
}
